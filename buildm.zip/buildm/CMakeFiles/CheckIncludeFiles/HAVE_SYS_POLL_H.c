/* */
#include <inttypes.h>
#include <sys/ioctl.h>
#include <sys/param.h>
#include <sys/poll.h>


int main(void){return 0;}

